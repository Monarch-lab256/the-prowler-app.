# Project guidance

- Preserve the established THE PROWLER visual identity: near-black, deep red, Barlow Condensed display type, Space Grotesk UI.
- Keep all image assets under `public/img/` and soundtrack under `public/audio/`.
- Keep the experience dependency-light and usable on Android browsers.
- Avoid stretching source photos: use `object-fit: contain` in the chapter view and cover-crop only inside the finale canvas.
- Respect reduced-motion preferences.
- Test audio start through a user gesture, replay, swipe navigation, fullscreen fallback and missing-asset behavior after changes.
