# THE PROWLER — WHOLE LOTTA RED

A cinematic birthday photo experience for Jordan ("Prowler").

## Run locally
Use a local static server from this folder (do not open `public/index.html` as a `file://` URL):

```bash
python -m http.server 8000
```

Then open http://localhost:8000/public/ in a browser, or configure the static host to publish `public/`.

## Included assets
- `public/audio/soundtrack.m4a` — supplied 94.46-second soundtrack.
- `public/img/photo-01` through `photo-15` — original embedded photographs extracted from the supplied 15-page PDF.
- `public/index.html` — cinematic slideshow, intro, controls, gift reveal and finale markup/styles.
- `public/finale.js` — adapted from the user-supplied finale engine, integrated with the slideshow, supplied soundtrack and the selected original photographs. Includes dynamic beat tracking, camera punches, velocity ramps, flash impacts, whip pans, film grain, freeze-frame RGB split, gift explosion and replay.

## Photo sequencing
Slideshow: 09, 06, 10, 01, 14, 15, 08, 11.
Finale: 02, 03, 04, 05, 07, 12, 13.
All 15 photographs are retained in the project.

## Audio timing notes
The supplied M4A decodes to 94.459 seconds at 44.1 kHz stereo. The transient envelope shows a recurring pulse close to 0.56 seconds (approximately 107 BPM), with elevated energy around 50–55 seconds and 70–85 seconds. The slideshow is paced to reach the gift sequence close to the first major transition. The finale canvas uses a ~0.56-second cut grid and follows the remaining soundtrack duration.

## Deployment
Publish the `public` directory as the static site root. `netlify.toml` sets this publish directory.

## Notes
The supplied `finale (1).js` was used as the finale foundation. Its expected image names and slideshow hooks were adapted to the actual project assets and markup. The slideshow and responsive presentation remain integrated in the same standalone static site.
