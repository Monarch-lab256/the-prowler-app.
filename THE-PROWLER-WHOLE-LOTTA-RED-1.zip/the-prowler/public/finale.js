(() => {
"use strict";
const $ = id => document.getElementById(id);
const slideAssets = [
 {tag:"ARCHIVE 01",title:"THE ORIGIN STORY",copy:"Before the aura. Before the name. Just the beginning.",img:"/img/photo-09.png"},
 {tag:"ARCHIVE 02",title:"THE LITTLE LEGEND",copy:"The early chapters. The spark was always there.",img:"/img/photo-06.png"},
 {tag:"PORTRAIT 03",title:"QUIET FLEX",copy:"Never needed to do too much. The camera already knew.",img:"/img/photo-10.png"},
 {tag:"EVOLUTION 04",title:"THE GLOW-UP",copy:"Different chapters. Same main-character energy.",img:"/img/photo-01.png"},
 {tag:"SQUAD 05",title:"THE DAY-ONES",copy:"The people, the laughter, the memories that stay.",img:"/img/photo-14.png"},
 {tag:"S3 ARCHIVE 06",title:"THE CLASSIC ERA",copy:"A whole classroom of stories. A whole lot of character.",img:"/img/photo-15.png"},
 {tag:"VAMP MODE 07",title:"FACE CARD: CLASSIFIED",copy:"A little mystery. A little mischief. Fully Prowler.",img:"/img/photo-08.png"},
 {tag:"THE FINALE 08",title:"HAPPY BIRTHDAY, PROWLER",copy:"Keep the memories. Keep the madness. Make the next chapter legendary.",img:"/img/photo-11.jpeg"}
];
const audio=$("music"); audio.src="/audio/soundtrack.m4a"; audio.loop=true;
let index=0, playing=false, muted=false, timer=0;
const reducedMotion=window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const slideDuration=6.15;
const dots=$("timeline");
$("total").textContent=String(slideAssets.length).padStart(2,"0");
function makeSlides(){slideAssets.forEach((s,i)=>{const b=document.createElement("button");b.className="dot"+(i===0?" active":"");b.title="Chapter "+(i+1);b.setAttribute("aria-label","Go to chapter "+(i+1));b.addEventListener("click",()=>show(i,true));dots.appendChild(b);});}
function show(i,manual=false){index=(i+slideAssets.length)%slideAssets.length;const s=slideAssets[index],im=$("photo");im.classList.add("enter");$("flash").classList.remove("go");void $("flash").offsetWidth;$("flash").classList.add("go");setTimeout(()=>{im.src=s.img;$("backdrop").style.backgroundImage=`url("${s.img}")`;im.alt=s.title;$("tag").textContent=s.tag;$("title").textContent=s.title;$("desc").textContent=s.copy;$("num").textContent=String(index+1).padStart(2,"0");im.classList.remove("enter");},reducedMotion?0:180);[...dots.children].forEach((d,n)=>d.classList.toggle("active",n===index));if(manual&&playing)schedule();}
function schedule(){clearTimeout(timer);if(!playing)return;timer=setTimeout(()=>{if(index>=slideAssets.length-1){playing=false;$("play").textContent="▶";showGift();}else{show(index+1);schedule();}},slideDuration*1000);}
function showGift(){clearTimeout(timer);playing=false;$("play").textContent="▶";window.startFinale();}
  const TRACK = '/audio/soundtrack.m4a';
  const P = (f) => '/img/' + f;

  // Section layout, measured in beats from the edit's first beat.
  const SECTIONS = [
    { id: 'fade',  b0: 0,     b1: 8,     imgs: ['photo-02.png', 'photo-03.png'],
      cap: ['THE PROWLER // FINAL CUT', 'WHERE IT<br>ALL STARTED.', 'FOREVER THE DAY-ONES'] },
    { id: 'punch', b0: 8,     b1: 16,    imgs: ['photo-04.png', 'photo-05.png', 'photo-07.png', 'photo-12.jpeg'],
      cap: ['CHAPTER 01 // THE DROP', 'MAIN<br>CHARACTER.', 'THE CAMERA ALREADY KNEW'] },
    { id: 'ramp',  b0: 16,    b1: 24,    imgs: ['photo-13.png', 'photo-02.png'],
      cap: ['CHAPTER 02 // LEVELS', 'LEVEL<br>UP.', 'NO SPEED LIMIT'] },
    { id: 'flash', b0: 24,    b1: 31.75, imgs: ['photo-03.png', 'photo-04.png', 'photo-05.png', 'photo-07.png'],
      cap: ['CHAPTER 03 // VAMP MODE', 'WHOLE<br>LOTTA RED.', 'FULL VOLUME. NO APOLOGIES'] },
    { id: 'whip',  b0: 31.75, b1: 38.25, imgs: ['photo-07.png', 'photo-13.png', 'photo-12.jpeg', 'photo-11.jpeg'],
      cap: ['CHAPTER 04 // NO BRAKES', 'NEVER<br>SLOWING DOWN.', 'ANOTHER YEAR. SAME AURA'] },
    { id: 'final', b0: 38.25, b1: 1e9,   imgs: ['photo-11.jpeg'],
      cap: ['THE PROWLER // FREEZE FRAME', 'HAPPY<br>BIRTHDAY,<br>PROWLER.', 'MAKE THE NEXT CHAPTER LEGENDARY'] },
  ];
  const FREEZE_AT = 40;   // beat where the final pose freezes
  const EDIT_LEN = 48;    // beats until the replay button appears
  const LEAD_IN = 0.7;    // seconds of explosion before the first beat

  const outro = $('outro'), scene = $('giftScene'), box = $('giftBox'), burst = $('burst');
  const edit = $('musicEdit'), canvas = $('editCanvas'), ctx = canvas.getContext('2d');
  const cap = document.querySelector('.edit-caption');

  /* ---------- images ---------- */
  const images = {};
  function loadImages() {
    SECTIONS.forEach((s) => s.imgs.forEach((f) => {
      if (images[f]) return;
      const im = new Image();
      im.decoding = 'async';
      im.src = P(f);
      im.onerror = () => { if (!im.dataset.fallback) { im.dataset.fallback = 1; im.src = '/img/' + f; } };
      images[f] = im;
    }));
  }
  const ready = (f) => { const im = images[f]; return im && im.complete && im.naturalWidth ? im : null; };

  /* ---------- beat analysis ---------- */
  let analysis = null, analysing = null;
  function analyse() {
    if (analysing) return analysing;
    analysing = (async () => {
      try {
        const buf = await (await fetch(TRACK)).arrayBuffer();
        const AC = window.AudioContext || window.webkitAudioContext;
        const ac = new AC();
        const ab = await new Promise((res, rej) => ac.decodeAudioData(buf, res, rej));
        ac.close && ac.close();
        analysis = trackBeats(ab);
      } catch (e) { console.warn('Beat analysis unavailable, using fallback tempo', e); }
      return analysis;
    })();
    return analysing;
  }

  function trackBeats(ab) {
    const sr = ab.sampleRate, n = ab.length;
    const L = ab.getChannelData(0), R = ab.numberOfChannels > 1 ? ab.getChannelData(1) : L;
    const hop = 512, F = Math.floor(n / hop), fps = sr / hop;
    const eA = new Float32Array(F), eL = new Float32Array(F), rms = new Float32Array(F);
    const a = Math.exp(-2 * Math.PI * 150 / sr);
    let lp = 0;
    for (let f = 0; f < F; f++) {
      let sa = 0, sl = 0;
      const o = f * hop;
      for (let i = 0; i < hop; i++) { const x = (L[o + i] + R[o + i]) * 0.5; lp = a * lp + (1 - a) * x; sa += x * x; sl += lp * lp; }
      eA[f] = Math.log(1e-4 + sa / hop); eL[f] = Math.log(1e-4 + sl / hop); rms[f] = Math.sqrt(sa / hop);
    }
    // onset strength: positive log-energy flux, bass weighted, local-mean removed
    const on = new Float32Array(F);
    for (let f = 1; f < F; f++) on[f] = Math.max(0, eA[f] - eA[f - 1]) + 1.5 * Math.max(0, eL[f] - eL[f - 1]);
    const w = Math.round(fps * 0.4), pre = new Float64Array(F + 1);
    for (let f = 0; f < F; f++) pre[f + 1] = pre[f] + on[f];
    const o2 = new Float32Array(F);
    let mean = 0, sq = 0;
    for (let f = 0; f < F; f++) {
      const lo = Math.max(0, f - w), hi = Math.min(F, f + w + 1);
      o2[f] = Math.max(0, on[f] - (pre[hi] - pre[lo]) / (hi - lo));
      mean += o2[f]; sq += o2[f] * o2[f];
    }
    mean /= F; const sd = Math.sqrt(Math.max(1e-9, sq / F - mean * mean));
    for (let f = 0; f < F; f++) o2[f] /= sd;

    // tempo via autocorrelation with a prior around ~135 BPM
    let bestLag = Math.round(fps * 0.45), bestScore = -1;
    for (let lag = Math.round(fps * 0.3); lag <= Math.round(fps * 1.0); lag++) {
      let s = 0;
      for (let f = 0; f + lag < F; f++) s += o2[f] * o2[f + lag];
      const prior = Math.exp(-0.5 * Math.pow(Math.log2(lag / (fps * 0.45)) / 0.9, 2));
      if (s * prior > bestScore) { bestScore = s * prior; bestLag = lag; }
    }
    const period = bestLag;

    // dynamic programming beat tracking
    const score = new Float32Array(F), back = new Int32Array(F).fill(-1);
    for (let f = 0; f < F; f++) {
      let best = 0, arg = -1;
      for (let p = f - 2 * period; p <= f - Math.round(period / 2); p++) {
        if (p < 0) continue;
        const pen = Math.log((f - p) / period);
        const v = score[p] - 100 * pen * pen;
        if (arg < 0 || v > best) { best = v; arg = p; }
      }
      score[f] = o2[f] + (arg >= 0 ? best : 0);
      back[f] = arg;
    }
    let end = F - 1;
    for (let f = Math.max(0, F - period); f < F; f++) if (score[f] > score[end]) end = f;
    const frames = [];
    for (let f = end; f >= 0; f = back[f]) frames.push(f);
    frames.reverse();
    const toT = (f) => (f * hop + hop / 2) / sr;
    const beats = frames.map(toT);
    const per = period / fps;
    const dur = ab.duration;
    while (beats[beats.length - 1] < dur + 60) beats.push(beats[beats.length - 1] + per);

    // loudness per beat + transient hits
    const nb = frames.length, E = new Float32Array(nb);
    let maxE = 1e-9;
    for (let k = 0; k < nb; k++) {
      const f0 = frames[k], f1 = k + 1 < nb ? frames[k + 1] : Math.min(F, f0 + period);
      let s = 0; for (let f = f0; f < f1; f++) s += rms[f];
      E[k] = s / Math.max(1, f1 - f0); maxE = Math.max(maxE, E[k]);
    }
    for (let k = 0; k < nb; k++) E[k] /= maxE;
    const hits = [];
    for (let f = 2; f < F - 2; f++) {
      if (o2[f] > 2.6 && o2[f] >= o2[f - 1] && o2[f] >= o2[f + 1] && o2[f] >= o2[f - 2] && o2[f] >= o2[f + 2]) hits.push(toT(f));
    }

    // find the drop: biggest energy rise that leaves room for the whole edit
    const avg = (i, j) => { let s = 0, c = 0; for (let k = Math.max(0, i); k < Math.min(nb, j); k++) { s += E[k]; c++; } return c ? s / c : 0; };
    let drop = 8, dropScore = -1e9;
    for (let d = 8; d + EDIT_LEN - 8 < nb; d++) {
      const s = 1.5 * (avg(d, d + 8) - avg(d - 8, d)) + 0.5 * avg(d, d + 24) + 0.05 * o2[frames[d]];
      if (s > dropScore) { dropScore = s; drop = d; }
    }
    const start = Math.max(0, Math.min(drop - 8, beats.length - EDIT_LEN - 1));
    return { beats, start, hits, period: per, duration: dur };
  }

  function fallbackGrid(from) {
    const per = 60 / 140, beats = [];
    for (let k = -4; k < 600; k++) beats.push(from + k * per);
    return { beats, start: 4, hits: [], period: per, fallback: true };
  }

  /* ---------- clock locked to the audio element ---------- */
  const clock = { useAudio: false, at: 0, p: 0, last: -1 };
  function now() {
    const pn = performance.now();
    if (!clock.useAudio) return clock.at + (pn - clock.p) / 1000;
    const ct = audio.currentTime;
    if (ct !== clock.last) { clock.last = ct; clock.at = ct; clock.p = pn; }
    if (audio.paused || audio.seeking || audio.ended) return clock.at;
    return clock.at + Math.min(0.25, (pn - clock.p) / 1000);
  }

  let A = null;
  function beatPos(t) {
    const b = A.beats;
    if (t < b[0]) return (t - b[0]) / A.period;
    let lo = 0, hi = b.length - 1;
    if (t >= b[hi]) return hi + (t - b[hi]) / A.period;
    while (hi - lo > 1) { const m = (lo + hi) >> 1; if (b[m] <= t) lo = m; else hi = m; }
    return lo + (t - b[lo]) / (b[lo + 1] - b[lo]);
  }
  const beatTime = (rel) => {
    const k = A.start + rel, i = Math.floor(k), b = A.beats;
    if (i < 0) return b[0] + k * A.period;
    if (i >= b.length - 1) return b[b.length - 1] + (k - b.length + 1) * A.period;
    return b[i] + (k - i) * (b[i + 1] - b[i]);
  };

  /* ---------- canvas helpers ---------- */
  let W = 0, H = 0, dpr = 1, grainPats = [], vignette = null, freezeCache = null;
  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    W = edit.clientWidth || innerWidth; H = edit.clientHeight || innerHeight;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    vignette = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.25, W / 2, H / 2, Math.max(W, H) * 0.75);
    vignette.addColorStop(0, 'rgba(0,0,0,0)'); vignette.addColorStop(1, 'rgba(0,0,0,.72)');
    freezeCache = null;
  }
  function makeGrain() {
    if (grainPats.length) return;
    for (let k = 0; k < 4; k++) {
      const c = document.createElement('canvas'); c.width = c.height = 220;
      const g = c.getContext('2d'), d = g.createImageData(220, 220);
      for (let i = 0; i < d.data.length; i += 4) { const v = 128 + (Math.random() - 0.5) * 255; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; }
      g.putImageData(d, 0, 0);
      grainPats.push(ctx.createPattern(c, 'repeat'));
    }
  }
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const smooth = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
  const easeIO = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

  function cover(im, s = 1, x = 0, y = 0, rot = 0, alpha = 1, g = ctx, w = W, h = H) {
    if (!im || alpha <= 0) return;
    const k = Math.max(w / im.naturalWidth, h / im.naturalHeight) * s;
    const iw = im.naturalWidth * k, ih = im.naturalHeight * k;
    g.save(); g.globalAlpha = alpha; g.translate(w / 2 + x, h / 2 + y); if (rot) g.rotate(rot);
    g.drawImage(im, -iw / 2, -ih / 2, iw, ih); g.restore();
  }
  function zoomBlur(im, s, amt, x = 0, y = 0, rot = 0) {
    cover(im, s, x, y, rot, 1);
    for (let i = 1; i <= 5 && amt > 0.02; i++) cover(im, s * (1 + 0.028 * i * amt), x, y, rot, 0.2 * amt);
  }
  function whipBlur(im, x, v, s = 1.08) {
    cover(im, s, x, 0, 0, 1);
    const spread = Math.min(W * 0.18, Math.abs(v) * W * 0.05);
    if (spread < 2) return;
    for (let i = -4; i <= 4; i++) if (i) cover(im, s, x + (i / 4) * spread, 0, 0, 0.16);
  }
  function overlay(color, alpha, mode = 'source-over') {
    if (alpha <= 0.003) return;
    ctx.save(); ctx.globalCompositeOperation = mode; ctx.globalAlpha = clamp(alpha); ctx.fillStyle = color;
    ctx.fillRect(-60, -60, W + 120, H + 120); ctx.restore();
  }
  let frameN = 0;
  function grain(alpha) {
    const pat = grainPats[frameN % grainPats.length];
    if (!pat) return;
    ctx.save(); ctx.globalCompositeOperation = 'overlay'; ctx.globalAlpha = alpha; ctx.fillStyle = pat;
    ctx.translate(-Math.random() * 220, -Math.random() * 220); ctx.fillRect(0, 0, W + 440, H + 440); ctx.restore();
  }
  function lastHitBefore(t, from) {
    let h = -1;
    for (const x of A.hits) { if (x > t) break; if (x >= from) h = x; }
    return h;
  }
  // three additive colour layers of the frozen final pose for the RGB split
  function buildFreeze(im) {
    const mk = () => { const c = document.createElement('canvas'); c.width = canvas.width; c.height = canvas.height; return c; };
    const base = mk(), bg = base.getContext('2d');
    bg.scale(dpr, dpr); cover(im, 1.06, 0, 0, 0, 1, bg, W, H);
    bg.globalCompositeOperation = 'saturation'; bg.globalAlpha = 0.25; bg.fillStyle = '#808080'; bg.fillRect(0, 0, W, H);
    freezeCache = ['#ff0000', '#00ff00', '#0000ff'].map((col) => {
      const c = mk(), g = c.getContext('2d');
      g.drawImage(base, 0, 0); g.globalCompositeOperation = 'multiply'; g.fillStyle = col; g.fillRect(0, 0, c.width, c.height);
      return c;
    });
  }

  /* ---------- the edit ---------- */
  let raf = 0, capKey = '', replayShown = false;
  function setCaption(key, c, final) {
    if (key === capKey) return;
    capKey = key;
    if (!c) { cap.classList.add('hidden'); return; }
    $('editTag').textContent = c[0]; $('editTitle').innerHTML = c[1]; $('editCopy').textContent = c[2];
    cap.classList.remove('hidden', 'slam'); cap.classList.toggle('final', !!final); void cap.offsetWidth; cap.classList.add('slam');
  }

  function render() {
    raf = requestAnimationFrame(render);
    frameN++;
    const t = now(), fb = beatPos(t), r = fb - A.start;
    const sinceBeat = t - A.beats[Math.max(0, Math.min(A.beats.length - 1, Math.floor(fb)))];
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
    ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
    $('editProgress').style.width = (clamp(r / EDIT_LEN) * 100).toFixed(2) + '%';

    if (r < 0) { grain(0.18); setCaption('pre', null); return; }
    const sec = SECTIONS.find((s) => r >= s.b0 && r < s.b1);
    const im = (i) => ready(sec.imgs[i]);
    let shakeX = 0, shakeY = 0, grainA = 0.07;

    if (sec.id === 'fade') {
      // Slow Fade + Film Grain
      const master = smooth(r / 1.6) * (1 - 0.65 * smooth(r - 7)) * (0.95 + Math.random() * 0.05);
      const xf = smooth((r - 3.5) / 2.5);
      cover(im(0), 1.04 + 0.012 * r, 0, 0, 0, master);
      cover(im(1), 1.12 - 0.01 * (r - 3.5), 0, 0, 0, master * xf);
      overlay('#808080', 0.45, 'saturation');
      overlay('rgb(255,222,190)', 0.85, 'multiply');
      grainA = 0.3;
      setCaption('fade', r > 1 ? sec.cap : null);
    } else if (sec.id === 'punch') {
      // Camera Punch on every beat, bigger on each cut
      const rr = r - 8, i = Math.floor(rr / 2), onCut = Math.floor(rr) % 2 === 0;
      const p = Math.exp(-sinceBeat * 9);
      const s = 1.03 + (onCut ? 0.22 : 0.11) * p;
      const rot = (Math.floor(rr) % 2 ? -1 : 1) * 0.018 * p;
      cover(im(i), s, 0, 0, rot);
      overlay('#fff', (rr < 1 ? 0.75 : 0.16) * Math.exp(-sinceBeat * 8), 'screen');
      setCaption('punch', sec.cap);
    } else if (sec.id === 'ramp') {
      // Velocity Ramp + Smooth Zoom
      const rr = r - 16;
      if (rr < 4) {
        const u = rr / 4;
        const pz = u < 0.65 ? 0.18 * (u / 0.65) : 0.18 + 0.82 * Math.pow((u - 0.65) / 0.35, 3);
        const speed = u < 0.65 ? 0.04 : (0.82 * 3 * Math.pow((u - 0.65) / 0.35, 2)) / 0.35 / 7;
        zoomBlur(im(0), 1.03 + 0.85 * pz, clamp(speed));
      } else {
        const u = (rr - 4) / 4, pz = 1 - Math.pow(1 - u, 4);
        zoomBlur(im(1), 1.7 - 0.6 * pz, clamp(Math.pow(1 - u, 3) * 1.2), 0, 0, 0.035 * (1 - pz));
        overlay('#fff', 0.55 * Math.exp(-(rr - 4) * 6), 'screen');
      }
      setCaption('ramp', sec.cap);
    } else if (sec.id === 'flash') {
      // Flash Impact + Shake on cuts and on the track's transients
      const rr = r - 24, i = Math.min(3, Math.floor(rr / 2));
      const cutT = beatTime(24 + i * 2), dc = t - cutT;
      const hit = lastHitBefore(t, beatTime(24)), dh = hit > 0 ? t - hit : 9;
      const amp = 30 * Math.exp(-dc * 6) + 14 * Math.exp(-dh * 10);
      shakeX = (Math.random() - 0.5) * 2 * amp; shakeY = (Math.random() - 0.5) * 2 * amp;
      ctx.save(); ctx.translate(shakeX, shakeY);
      cover(im(i), 1.08 + 0.04 * Math.exp(-sinceBeat * 8), 0, 0, (Math.random() - 0.5) * 0.004 * amp);
      ctx.restore();
      overlay('#fff', Math.exp(-dc * 7), 'source-over');
      overlay('#ff1744', 0.4 * Math.exp(-dh * 10), 'screen');
      setCaption('flash', sec.cap);
    } else if (sec.id === 'whip') {
      // Whip Pan between shots, centred on the beat
      const cuts = [32, 35, 38], half = 0.25;
      let drawn = false;
      for (let c = 0; c < cuts.length; c++) {
        if (r >= cuts[c] - half && r < cuts[c] + half) {
          const q = (r - (cuts[c] - half)) / (half * 2), e = easeIO(q);
          const v = q < 0.5 ? 12 * q * q : 12 * (1 - q) * (1 - q);
          whipBlur(im(c), -e * W * 1.05, v * 3);
          whipBlur(im(c + 1), (1 - e) * W * 1.05, v * 3);
          drawn = true;
        }
      }
      if (!drawn) {
        const i = r < 35 ? 1 : 2, base = i === 1 ? 32 : 35;
        whipBlur(im(i), 24 - 16 * (r - base), 0);
      }
      setCaption('whip', sec.cap);
    } else {
      // Final pose: Freeze Frame + RGB Split
      const f = im(0);
      if (r < FREEZE_AT) {
        cover(f, 1.12 - 0.06 * smooth((r - 38.25) / 1.75));
        setCaption('final-pre', null);
      } else if (f) {
        if (!freezeCache) buildFreeze(f);
        const df = t - beatTime(FREEZE_AT);
        const pulse = Math.exp(-sinceBeat * 6);
        const dx = 3 + 38 * Math.exp(-df * 3) + 14 * pulse;
        const amp = 22 * Math.exp(-df * 7);
        ctx.save(); ctx.translate((Math.random() - 0.5) * amp, (Math.random() - 0.5) * amp);
        ctx.globalCompositeOperation = 'lighter';
        ctx.drawImage(freezeCache[0], -dx, -dx * 0.25, W, H);
        ctx.drawImage(freezeCache[1], 0, 0, W, H);
        ctx.drawImage(freezeCache[2], dx, dx * 0.25, W, H);
        ctx.restore();
        if (pulse > 0.35 && Math.floor(fb) % 2 === 0) {
          for (let k = 0; k < 3; k++) {
            const y = Math.random() * H, h = 8 + Math.random() * 40, sh = (Math.random() - 0.5) * 70 * pulse;
            ctx.drawImage(canvas, 0, y * dpr, canvas.width, h * dpr, sh, y, W, h);
          }
        }
        overlay('#fff', Math.exp(-df * 5), 'source-over');
        ctx.save(); ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = 3; ctx.globalAlpha = clamp(1 - df * 0.6, 0.25);
        ctx.strokeRect(14, 14, W - 28, H - 28); ctx.restore();
        setCaption('final', sec.cap, true);
        if (r >= EDIT_LEN && !replayShown) { replayShown = true; $('editReplay').classList.add('show'); }
      }
      grainA = 0.1;
    }
    ctx.fillStyle = vignette; ctx.globalAlpha = 1; ctx.fillRect(0, 0, W, H);
    grain(grainA);
  }

  function startEdit() {
    cancelAnimationFrame(raf);
    replayShown = false; capKey = ''; freezeCache = null;
    $('editReplay').classList.remove('show');
    const hasAudio = !!audio.src && audio.error == null;
    clock.useAudio = hasAudio; clock.last = -1;
    if (analysis) {
      A = analysis;
      if (hasAudio) {
        audio.loop = false;
        try { audio.currentTime = Math.max(0, A.beats[A.start] - LEAD_IN); } catch (e) {}
      }
    } else {
      const base = hasAudio ? audio.currentTime : 0;
      A = fallbackGrid(base + LEAD_IN);
    }
    if (!hasAudio) { clock.at = 0; clock.p = performance.now(); }
    if (hasAudio) { audio.muted = typeof muted !== 'undefined' ? muted : false; audio.play().catch(() => {}); }
    resize(); makeGrain();
    edit.classList.add('active');
    setTimeout(() => edit.classList.add('visible'), 420);
    render();
  }

  /* ---------- explosion ---------- */
  let exploded = false;
  function boom() {
    try {
      const AC = window.AudioContext || window.webkitAudioContext, ac = new AC(), t = ac.currentTime;
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(36, t + 0.55);
      g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.7);
      const nb = ac.createBuffer(1, ac.sampleRate * 0.4, ac.sampleRate), d = nb.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 3);
      const ns = ac.createBufferSource(), ng = ac.createGain(); ns.buffer = nb; ng.gain.value = 0.35;
      o.connect(g).connect(ac.destination); ns.connect(ng).connect(ac.destination);
      o.start(t); o.stop(t + 0.75); ns.start(t);
      setTimeout(() => ac.close && ac.close(), 1200);
    } catch (e) {}
  }
  function explode() {
    if (exploded) return;
    exploded = true;
    box.classList.add('explode');
    scene.classList.add('gone');
    burst.innerHTML = '';
    const colors = ['#ff1744', '#ffe2e8', '#ff9aaa', '#ffffff', '#ffd54f', '#9d001e'];
    for (let i = 0; i < 90; i++) {
      const el = document.createElement('i'), ang = Math.random() * Math.PI * 2, dist = 140 + Math.random() * Math.max(innerWidth, innerHeight) * 0.6;
      el.style.setProperty('--x', Math.cos(ang) * dist + 'px'); el.style.setProperty('--y', Math.sin(ang) * dist + 'px');
      el.style.setProperty('--r', Math.random() * 360 + 'deg'); el.style.setProperty('--c', colors[i % colors.length]);
      el.style.animationDuration = 0.8 + Math.random() * 0.8 + 's';
      burst.appendChild(el);
    }
    const fl = $('outroFlash'); fl.classList.remove('go'); void fl.offsetWidth; fl.classList.add('go');
    outro.classList.remove('quake'); void outro.offsetWidth; outro.classList.add('quake');
    if (navigator.vibrate) navigator.vibrate([60, 30, 120]);
    boom();
    startEdit();
  }


  /* ---------- slideshow integration ---------- */
  window.warmFinale = () => { loadImages(); analyse(); };
  window.outroOpen = () => outro.classList.contains('show');
  window.goNext = () => { if (index >= slideAssets.length - 1) showGift(); else show(index + 1, true); };
  window.startFinale = () => {
    clearTimeout(timer); playing = false; $('play').textContent = '▶'; warmFinale();
    exploded = false; box.classList.remove('explode'); scene.classList.remove('gone'); scene.style.display='flex'; burst.innerHTML='';
    edit.classList.remove('active','visible'); cap.classList.add('hidden'); $('editReplay').classList.remove('show');
    outro.classList.add('show');
    // Keep the soundtrack moving into the gift; the finale engine will lock to its actual audio clock.
    if (audio.src && audio.paused && !muted) audio.play().catch(() => {});
    // A deliberate tap opens the gift. No surprise auto-explosion.
  };
  function closeOutro(){ cancelAnimationFrame(raf); outro.classList.remove('show'); edit.classList.remove('active','visible'); $('editReplay').classList.remove('show'); audio.loop=true; }
  scene.addEventListener('pointerdown', explode);
  scene.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();explode();}});
  $('outroClose').addEventListener('click',closeOutro);
  $('editReplay').addEventListener('click',()=>{if(!analysis&&analysing)analysing.then(startEdit);else startEdit();});
  window.addEventListener('resize',()=>{if(edit.classList.contains('active'))resize();});
  document.addEventListener('keydown',e=>{if(outroOpen()&&e.key==='Escape')closeOutro();});

  async function startMovie(){
    $('intro').classList.add('hide'); warmFinale(); analyse(); playing=true; $('play').textContent='Ⅱ';
    audio.loop=false; audio.muted=muted; audio.volume=.82;
    try{await audio.play();}catch(e){$('sound').textContent='♪ TAP SOUND';}
    show(0); schedule();
  }
  function togglePlay(){if(!playing){if(outroOpen()){closeOutro();} startMovie();}else{playing=false;clearTimeout(timer);$('play').textContent='▶';audio.pause();}}
  $('start').addEventListener('click',startMovie);
  $('play').addEventListener('click',togglePlay);
  $('prev').addEventListener('click',()=>{if(!outroOpen())show(index-1,true);});
  $('next').addEventListener('click',()=>window.goNext());
  $('sound').addEventListener('click',async()=>{muted=!muted;audio.muted=muted;if(!muted&&audio.paused&&playing){try{await audio.play();}catch(e){}}$('sound').textContent=muted?'♪ SOUND OFF':'♪ SOUND ON';$('sound').classList.toggle('on',!muted);});
  $('full').addEventListener('click',async()=>{try{if(!document.fullscreenElement)await document.documentElement.requestFullscreen?.();else await document.exitFullscreen?.();}catch(e){}});
  document.addEventListener('keydown',e=>{if(outroOpen())return;if(e.key==='ArrowRight')window.goNext();if(e.key==='ArrowLeft')show(index-1,true);if(e.code==='Space'&&!/BUTTON/.test(document.activeElement.tagName)){e.preventDefault();togglePlay();}});
  let touchX=0;document.addEventListener('touchstart',e=>{touchX=e.changedTouches[0].screenX;},{passive:true});document.addEventListener('touchend',e=>{if(outroOpen())return;const dx=e.changedTouches[0].screenX-touchX;if(Math.abs(dx)>48){dx<0?window.goNext():show(index-1,true);}},{passive:true});
  audio.addEventListener('ended',()=>{if(!outroOpen())showGift();});
  audio.addEventListener('error',()=>$('sound').textContent='♪ AUDIO ERROR');
  makeSlides(); show(0); window.warmFinale();
})();
